# db/db_connection.py

from flask_sqlalchemy import SQLAlchemy
# from pymysql import install_as_MySQLdb

# Create a SQLAlchemy instance
db = SQLAlchemy()
# install_as_MySQLdb()